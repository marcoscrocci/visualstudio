Valida��o de Data e Moeda em ASP.Net MVC
======================

Exemplo de valida��o publicado no meu blog, para saber mais acesse:

http://cleytonferrari.com/validacao-de-data-e-moeda-asp-net-mvc-jquery-validation-em-portugues/