﻿using Projeto02_EventosMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Projeto02_EventosMVC.Db
{
    public class DadosContato
    {
        public static void AdicionarContato(Contato contato)
        {
            using (var ctx = new ContatosDbContext())
            {
                ctx.Contatos.Add(contato);
                ctx.SaveChanges();
            }
        }

        //metodo que retorna um Contato com base no id do Convidado
        public static Contato BuscarContato(int idConvidado)
        {
            using (var ctx2 = new ContatosDbContext())
            {
                Contato contato = ctx2
                    .Contatos
                    .FirstOrDefault(c => c.IdConvidado == idConvidado);
                //contato /mensagem não encontrada para este convidado
                if (contato == null)
                {
                    return new Contato()
                    {
                        Id = -1,
                        IdConvidado = idConvidado,
                        DataContato = DateTime.Now,
                        Mensagem = "Nenhuma mensagem para este convidado"
                    };
                }
                else
                {
                    return contato;
                }
            }
        }

    }
}