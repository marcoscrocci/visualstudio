﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projeto02_EventosMVC.Controllers
{
    public class ExemplosJsController : Controller
    {
        // GET: ExemplosJs
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Exemplo01()
        {
            return View();
        }

        public ActionResult Exemplo02()
        {
            return View();
        }
        public ActionResult Exemplo03()
        {
            return View();
        }
        public ActionResult Exemplo04()
        {
            return View();
        }
        public ActionResult Exemplo05()
        {
            return View();
        }
    }
}