﻿function exibirDados() {
    var cnpj = document.getElementById("cnpj").value;
    var nome = document.getElementById("nome").value;
    var email = document.getElementById("email").value;

    //vamos formar uma nova string contendo o resultado a
    //ser apresentado para o usuário
    var mensagem = "Cnpj: " + cnpj +
        "\nNome: " + nome +
        "\nEmail: " + email;

    //exibindo a mensagem na tela
    alert(mensagem);
}
var botao = document.getElementById("btnEnviar2");
//registramos o evento click do botão "btnEnviar2" para executar
//a função exibirDados()
botao.addEventListener("click", exibirDados);


document.getElementById("btnEnviar3")
    .addEventListener("click", () => { //arrow function
        alert("Usando função anônima");
    });