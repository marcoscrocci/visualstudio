﻿$(document).ready(function () {

    var cursos = ["Java", "SQL Server", "ASP.NET", "PHP"];

    //instrução para preencher o elemento <select> com 
    //estes cursos
    $.each(cursos, function (i, item) {
        $("#lista").append($("<option>", {
            value: i,
            text: item
        }));
    });

    $("#btnEnviar").click(function () {
        //obtendo o conteudo dos campos de entrada
        var nome = $("#nome").val();
        var curso = $("#lista").val();
        var idade = $("#idade").val();

        //definir a variavel para armazenar a resposta
        var resultado;

        //verificamos se o elemento div possui alguma classe
        //css. Se possuir, nós a removemos
        if ($("#resposta").hasClass("erro")) {
            $("#resposta").removeClass("erro");
        }

        if ($("#resposta").hasClass("ok")) {
            $("#resposta").removeClass("ok");
        }

        if (idade == "") {
            resultado = "Idade inválida";
            $("#resposta").addClass("erro");
        }
        else {
            if (idade < 18) {
                resultado = "Menor de Idade";
            } else {
                resultado = "Maior de Idade";
            }
            $("#resposta").addClass("ok");
        }

        $("#resposta").hide();
        $("#resposta").html(resultado);
        $("#resposta").fadeIn(3000);
        $("#resposta").fadeOut(3000);
    });
});