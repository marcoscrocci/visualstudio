﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.SessionState;

namespace Projeto02_EventosMVC.Helper
{
    public class CultureHelper
    {
        //SessionState: mantém o estado da aplicação entre 
        //requisições
        protected HttpSessionState session;

        //construtor
        public CultureHelper(HttpSessionState sessionState)
        {
            session = sessionState;
        }

        //propriedades (estaticas)
        public static int CurrentCulture
        {
            get
            {
                if(Thread.CurrentThread.CurrentUICulture.Name == "en-us")
                {
                    return 1; //idioma inglês
                }
                else
                {
                    return 0; //idioma portugues (padrao)
                }
            }
            set
            {
                if(value == 1)
                {
                    Thread.CurrentThread.CurrentUICulture = new
                        System.Globalization.CultureInfo("en-us");
                }
                else
                {
                    Thread.CurrentThread.CurrentUICulture = new
                        System.Globalization.CultureInfo("pt-br");
                }
            }
        }

    }
}