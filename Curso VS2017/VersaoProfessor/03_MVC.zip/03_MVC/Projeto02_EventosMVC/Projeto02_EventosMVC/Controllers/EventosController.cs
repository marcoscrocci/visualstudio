﻿using Projeto02_EventosMVC.Db;
using Projeto02_EventosMVC.Helper;
using Projeto02_EventosMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Projeto02_EventosMVC.Controllers
{
    public class EventosController : Controller
    {
        //sobrescrevemos o método ExecureCore() - executado no inicio da aplicação
        protected override void ExecuteCore()
        {
            int culture = 0;

            if(this.Session == null || this.Session["CurrentCulture"] == null)
            {
                int.TryParse(System.Configuration
                    .ConfigurationManager.AppSettings["Culture"], out culture);
                this.Session["CurrentCulture"] = culture;
            }
            else
            {
                culture = (int)this.Session["CurrentCulture"];
            }

            CultureHelper.CurrentCulture = culture;
            base.ExecuteCore();
        }

        //desabilitar recursos assíncronos na ocasião da verificação da cultura
        protected override bool DisableAsyncSupport => true;

        //criando o action poara alterar o idioma
        public ActionResult MudarCultura(int id)
        {
            //Alterar a cultura para o usuário atual
            CultureHelper.CurrentCulture = id;

            //Armazena a cultura na sessão
            Session["CurrentCulture"] = id;

            //Redireciona para a mesma página de onde partiu a requisição
            return Redirect(Request.UrlReferrer.ToString());
        }


        // GET: Eventos
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Incluir()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Incluir(Evento evento)
        {
            if (ModelState.IsValid)
            {
                evento.Descricao = evento.Descricao.RetirarAcentos();
                Dados.IncluirEvento(evento);
                ViewBag.Mensagem = "Evento " + evento.Descricao + " Adicionado!";
                return RedirectToAction("Listar");
            }
            else
            {
                return View();
            }
        }

        public ActionResult Listar()
        {
            return View(Dados.ListarEventos());
        }

        public ActionResult Alterar(int? id)
        {
            if(id == null)
            {
                ViewBag.Erro = "Nenhum parâmetro foi fornecido na URL";
                return View("Erro");
            }
            return View(Dados.BuscarEvento(id));
        }

        [HttpPost]
        public ActionResult Alterar(Evento evento)
        {
            if (ModelState.IsValid)
            {
                evento.Descricao = evento.Descricao.RetirarAcentos();

                Dados.AlterarEvento(evento);
                ViewBag.Mensagem = "Evento " + evento.Descricao + " Alterado!";
                return View("Listar", Dados.ListarEventos());
            }
            return View();
        }
        
        public ActionResult Remover(int? id)
        {             
            if (id == null)
            {
                ViewBag.Erro = "Nenhum parâmetro foi fornecido na URL";
                return View("Erro");
            }
            var evento = Dados.BuscarEvento(id);
            if(evento == null)
            {
                ViewBag.Erro = "Evento inexistente";
                return View("Erro");
            }
            return View(Dados.BuscarEvento(id));
        }

        [HttpPost]
        public ActionResult Remover(Evento evento)
        {
            try
            {
                ViewBag.Mensagem = "Evento Removido!";
                Dados.RemoverEvento(evento.Id);
                return View("Listar", Dados.ListarEventos());
            }
            catch (Exception ex)
            {
                ViewBag.Erro = "ERRO: " + ex.Message;
                return View("Erro");
            }
        }

    }
}