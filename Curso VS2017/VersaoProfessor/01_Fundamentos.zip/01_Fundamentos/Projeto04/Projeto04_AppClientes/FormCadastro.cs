﻿
using Projeto04_AppClientes.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto04_AppClientes
{
    public partial class FormCadastro : Form
    {
        public FormCadastro()
        {
            InitializeComponent();
        }

        List<string> nomes = new List<string>();

        private void incluirClienteButton_Click(object sender, EventArgs e)
        {
            try
            {
                Cliente cliente;
                string documento = documentoTextBox.Text;
                if(documento.Length == 11)
                {
                    cliente = new ClientePF();
                }
                else if(documento.Length == 14)
                {
                    cliente = new ClientePJ();
                } else
                {
                    throw new Exception("Documento inválido");
                }
                cliente.Nome = nomeTextBox.Text;
                cliente.Telefone = telefoneTextBox.Text;
                cliente.Email = emailTextBox.Text;
                cliente.NumeroDocumento = documento;

                clienteComboBox.Items.Add(cliente);
                nomes.Add(cliente.Nome);

                MessageBox.Show("Cliente adicionado com sucesso");

                nomeTextBox.Clear();
                telefoneTextBox.Clear();
                emailTextBox.Clear();
                documentoTextBox.Clear();
                nomeTextBox.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Erro", 
                    MessageBoxButtons.OK, 
                    MessageBoxIcon.Error);
            }
        }

        private void incluirAutomovelButton_Click(object sender, EventArgs e)
        {
            try
            {
                if(clienteComboBox.Items.Count == 0)
                {
                    throw new InvalidOperationException("Não existem clientes disponiveis");
                }

                Automovel auto = new Automovel();
                auto.Marca = marcaTextBox.Text;
                auto.Modelo = modeloTextBox.Text;
                auto.Ano = int.Parse(anoTextBox.Text);

                object cliente = clienteComboBox.SelectedItem;
                if(cliente is ClientePF)
                {
                    /*
                     * Se a variavel cliente não referenciar 
                     * uma instancia de ClientePF, a instrução:
                     * (ClientePF)cliente
                     * lança uma exceção do tipo InvalidCastException
                     */
                    auto.InfoCliente = (ClientePF)cliente;
                    
                } else if (cliente is ClientePJ)
                {
                    //auto.InfoCliente = (ClientePJ)cliente;
                    /*
                     * Se a variavel cliente não referenciar uma instancia
                     * de ClientePJ, a propriedade InfoCliente receberá
                     * uma referncia nula (null)
                     */ 
                    auto.InfoCliente = cliente as ClientePJ;
                }

                ((Cliente)cliente).Automoveis.Add(auto);

                MessageBox.Show(auto.Mostrar());
            }
            catch(InvalidOperationException ex)
            {
                StreamWriter sw = new 
                    StreamWriter(@"C:\Users\emilio\Documents\Curso_VS2017\erro.log", true);
                sw.WriteLine("[" + DateTime.Now + "] - " + ex.Message);
                sw.Close();
                MessageBox.Show("Um arquivo foi gerado com o erro");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ocorreu o seguinte erro: " + ex.Message);
            }


        }

        private void listarAutomoveisButton_Click(object sender, EventArgs e)
        {
            try
            {
                //obtendo o objeto cliente no combobox
                Cliente cliente = (Cliente)clienteComboBox.SelectedItem;
                automoveisListBox.Items.Clear();
                if(cliente.Automoveis.Count == 0)
                {
                    automoveisListBox.Items
                        .Add("Nenhum automovel para este cliente");
                } else
                {
                    cliente.Automoveis.Sort();

                    foreach (Automovel item in cliente.Automoveis)
                    {
                        automoveisListBox.Items
                            .Add(item.Marca + " _ " + item.Modelo);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void listarClientesButton_Click(object sender, EventArgs e)
        {
            nomes.Sort();
            nomesListBox.Items.Clear();
            foreach (var item in nomes)
            {
                nomesListBox.Items.Add(item);
            }
        }
    }
}
