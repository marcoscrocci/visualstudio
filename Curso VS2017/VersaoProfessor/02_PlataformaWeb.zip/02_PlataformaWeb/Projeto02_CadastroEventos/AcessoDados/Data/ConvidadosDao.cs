﻿using AcessoDados.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AcessoDados.Data
{
    public class ConvidadosDao : Dao<Convidado>
    {
        public override Convidado Buscar(int id)
        {
            throw new NotImplementedException();
        }

        public override void Incluir(Convidado elemento)
        {
            try
            {
                AbrirConexao();
                StringBuilder sb = new StringBuilder();
                sb.Append(" INSERT INTO TBConvidados")
                    .Append(" (IdEvento, Nome, Email)")
                    .Append(" Values (@IdEvento, @Nome, @Email)");

                cmd.CommandText = sb.ToString();
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@IdEvento", elemento.IdEvento);
                cmd.Parameters.AddWithValue("@Nome", elemento.Nome);
                cmd.Parameters.AddWithValue("@Email", elemento.Email);
                cmd.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                FecharConexao();
            }
        }

        public override DataTable Listar(int id = -1)
        {
            DataTable dt = new DataTable();
            try
            {
                AbrirConexao();
                StringBuilder sb = new StringBuilder();
                sb.Append(" select TBEventos.Descricao as Evento,")
                    .Append(" TBConvidados.Nome as Convidado,")
                    .Append(" TBConvidados.Email as Email")
                    .Append(" From TBEventos, TBConvidados")
                    .Append(" Where TBEventos.Id = TBConvidados.IdEvento");


                cmd.Parameters.Clear();
                if (id > 0)
                {
                    sb.Append(" And TBConvidados.IdEvento = @IdEvento");                    
                    cmd.Parameters.AddWithValue("@IdEvento", id);
                }
                cmd.CommandText = sb.ToString();
                adapter.SelectCommand = cmd;
                adapter.Fill(dt);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                FecharConexao();
            }
            return dt;
        }
    }
}
