﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Projeto02_CadastroEventos.Usuario
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void confirmarButton_Click(object sender, EventArgs e)
        {
            string nome = Nome.Text;
            string senha = Senha.Text;

            string url = Request.QueryString["ReturnUrl"];


            var usuarioStore = new UserStore<IdentityUser>();
            var usuarioGerenciador =
            new UserManager<IdentityUser>(usuarioStore);

            var usuario = usuarioGerenciador.Find(nome, senha);
            if (usuario != null)
            {
                var gerenciadorDeAutenticacao = HttpContext.Current
                .GetOwinContext().Authentication;

                var identidade = usuarioGerenciador.CreateIdentity(usuario,
                DefaultAuthenticationTypes.ApplicationCookie);

                gerenciadorDeAutenticacao.SignIn(
                new AuthenticationProperties()
                { IsPersistent = false }, identidade);

                if (string.IsNullOrEmpty(url))
                {
                    Response.Redirect("~/Menu");
                }
                else
                {
                    Response.Redirect(url);
                }                
            }
            else
            {
                mensagemErro.Text = "Usuario ou senha invalida.";
            }
        }
    }
}