﻿using System;

namespace Projeto01_ConsoleApp
{
    public class Class1
    {
    }
}
