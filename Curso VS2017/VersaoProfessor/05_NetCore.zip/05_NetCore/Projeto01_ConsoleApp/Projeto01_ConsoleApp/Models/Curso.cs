﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Projeto01_ConsoleApp.Models
{
    public class Curso
    {
        public int CursoId { get; set; }
        public string Descricao { get; set; }
        public int CargaHoraria { get; set; }
    }
}
