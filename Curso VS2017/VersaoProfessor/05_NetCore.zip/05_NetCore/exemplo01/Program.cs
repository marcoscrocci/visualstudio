﻿using System;

namespace exemplo01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Exemplo .NET Core");
        }
    }
}
