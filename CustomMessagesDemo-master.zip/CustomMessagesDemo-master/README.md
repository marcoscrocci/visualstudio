# Asp.net Core Mvc demo project about validation messages customization

The example is dicussed [here](https://blogs.msdn.microsoft.com/mvpawardprogram/2017/05/09/aspnetcore-mvc-error-message/). 
It shows how to customize all standard validation messages, and how to provide standard customized messages for all validation attributes.
