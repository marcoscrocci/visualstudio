﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreLocalizationSample
{
    /// <summary>
    /// Dummy Class for shared resources
    /// </summary>
    public class SharedResources
    {
    }
}
